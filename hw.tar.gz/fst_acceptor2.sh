#!/bin/sh
python fst_acceptor2.py $1 $2